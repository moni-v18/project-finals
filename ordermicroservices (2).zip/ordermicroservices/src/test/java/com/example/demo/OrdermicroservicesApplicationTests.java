package com.example.demo;

import org.junit.jupiter.api.Test;


import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.controller.OrderController;
import com.example.demo.entity.Orders1;
import com.example.demo.service.OrderServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
@WebMvcTest(OrderController.class)
@SpringBootTest
class OrdermicroservicesApplicationTests {


    @Autowired
    private MockMvc mockMvc;

    @Mock
    private OrderServiceImpl orderService;

    @Test
    public void testGetAllOrders() throws Exception {
        List<Orders1> orders = Arrays.asList(new Orders1(1, 101, 2, "Confirmed"),
                                             new Orders1(2, 102, 1, "Shipped"));
        when(orderService.getAllOrders()).thenReturn(orders);

        mockMvc.perform(get("/orders/getAll"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$[0].orderId").value(1))
               .andExpect(jsonPath("$[1].orderId").value(2));
    }

    @Test
    public void testGetOrderById() throws Exception {
        Orders1 order = new Orders1(1, 101, 2, "Confirmed");
        when(orderService.getOrderById(1)).thenReturn(order);

        mockMvc.perform(get("/orders/getOrder/1"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.orderId").value(1));
    }

    @Test
    public void testSaveOrder() throws Exception {
        Orders1 order = new Orders1(1, 101, 2, "Confirmed");
        when(orderService.addOrder(order)).thenReturn("Order saved successfully!");

        mockMvc.perform(post("/orders/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(order)))
               .andExpect(status().isOk())
               .andExpect(content().string("Order saved successfully!"));
    }

    @Test
    public void testUpdateOrder() throws Exception {
        Orders1 order = new Orders1(1, 101, 2, "Shipped");
        when(orderService.updateOrder(order)).thenReturn(order);

        mockMvc.perform(put("/orders/update")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(order)))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.orderStatus").value("Shipped"));
    }

    @Test
    public void testDeleteOrder() throws Exception {
        when(orderService.deleteOrder(1)).thenReturn("Order deleted successfully!");

        mockMvc.perform(delete("/orders/delete/1"))
               .andExpect(status().isOk())
               .andExpect(content().string("Order deleted successfully!"));
    }
}

