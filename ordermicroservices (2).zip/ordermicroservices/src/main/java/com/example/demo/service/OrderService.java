package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Orders1;
import com.example.demo.exception.OrderNotFound;

public interface OrderService {
    String addOrder(Orders1 order);
    Orders1 updateOrder(Orders1 order);
    String deleteOrder(int orderId);
    Orders1 getOrderById(int orderId) throws OrderNotFound;
    List<Orders1> getAllOrders();
}