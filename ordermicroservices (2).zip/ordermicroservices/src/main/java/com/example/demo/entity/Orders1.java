package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

	@Data
	@Entity
	@NoArgsConstructor
	@AllArgsConstructor
	public class Orders1 {
	    @Id
	    private int orderId;
	    @NotNull(message="book id cannot be empty")
	    private int bookId;
	    @NotNull(message="quantity cannot be empty")
	    private int quantity;
	    @NotEmpty(message="order status cannot be empty")
	    private String orderStatus;
	}


