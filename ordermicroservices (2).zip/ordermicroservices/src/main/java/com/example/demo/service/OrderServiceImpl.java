package com.example.demo.service;

	import java.util.List;
	import java.util.Optional;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;



//import com.example.demo.dto.BookDTO;

//import com.example.demo.dto.OrderBookDTO;

import com.example.demo.entity.Orders1;

import com.example.demo.exception.OrderNotFound;
import com.example.demo.repository.OrderRepository;

	@Service
	public class OrderServiceImpl implements OrderService {

	    @Autowired
	    OrderRepository repository;
		@Autowired
		RestTemplate restTemplate;

	    @Override
	    public String addOrder(Orders1 order) {
	        repository.save(order);
	        return "Order saved successfully!";
	    }

	    @Override
	    public Orders1 updateOrder(Orders1 order) {
	        return repository.save(order);
	    }

	    @Override
	    public String deleteOrder(int orderId) {
	        repository.deleteById(orderId);
	        return "Order deleted successfully!";
	    }
	   
		


	    @Override
	    public Orders1 getOrderById(int orderId) throws OrderNotFound {
	        Optional<Orders1> optional = repository.findById(orderId);
	        if(optional.isPresent()) 
				return optional.get();
	       
			else
				throw new OrderNotFound("No Orders Found With Given Id!!!");
	  
	    }

	    @Override
	    public List<Orders1> getAllOrders() {
	        return repository.findAll();
	    }

//		public Orders1 getOrder(int orderId) {
//			Optional<Orders1> optional = repository.findById(orderId);
//			BookDTO Books = restTemplate.getForObject("http://BOOKSMICROSERVICE/books/getById/" + bookId,
//					BookDTO.class);
//			System.out.println(Books);
//			OrderBookDTO orderBooks = new OrderBookDTO(orderId, Books.getList());
//			return orderBooks;
//		}

}
