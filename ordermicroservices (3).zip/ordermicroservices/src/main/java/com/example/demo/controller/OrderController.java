package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.BookDTO;
//import com.example.demo.dto.OrderBookDTO;
import com.example.demo.entity.Order1;
import com.example.demo.exception.OrderNotFound;
import com.example.demo.service.OrderServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    OrderServiceImpl service;
    
//    @RequestMapping(method = RequestMethod.POST,consumes = "application/json",value="/save")
//    @PostMapping("/save")
//    public String saveOrder(@PathVariable("id") int cartId) {
//        return service.addOrder(cartId);
//    }
    @RequestMapping(method = RequestMethod.POST,consumes = "application/json",value="/save")
    @PostMapping("/save")
    public String saveOrder(@Valid @RequestBody Order1 order) {
      return service.addOrder1(order);
  }
    @PostMapping("/place/{cartId}")
	public Order1 placeOrder(@PathVariable("cartId") int cartId) throws OrderNotFound {
 
		return service.placeOrder(cartId);
 
	}
                        
    @PutMapping("/update")
    public Order1 updateOrder(@Valid @RequestBody Order1 order) {
        return service.updateOrder(order);
    }
 
    @DeleteMapping("/delete/{id}")
    public String deleteOrder(@PathVariable("id") int orderId) {
        return service.deleteOrder(orderId);
    }

    @GetMapping("/getOrder/{id}")
    public Order1 getOrder(@PathVariable("id") int orderId) throws OrderNotFound {
        return service.getOrderById(orderId);
    }

//	@GetMapping("/getOrder/{orderId}") // http://localhost:7771/cart/getCart/1
//	public OrderBookDTO getOrder(@PathVariable("orderId") int orderId) {
//		System.out.println("in getcart");
//		return service.getOrder(orderId);
//	}
    @GetMapping("/getBooksByOrderId/{orderId}")
    public BookDTO getBooksByOrderId(@PathVariable("orderId") int orderId) throws OrderNotFound {
        return service.getBooksByOrderId(orderId);
    }

    @GetMapping("/getAll")
    public List<Order1> getAllOrders() {
        return service.getAllOrders();
    }
}