package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Order1;
import com.example.demo.exception.OrderNotFound;

public interface OrderService {
    String addOrder1(Order1 order);
   // String addOrder(int cartId);
    Order1 updateOrder(Order1 order);
    String deleteOrder(int orderId);
    Order1 getOrderById(int orderId) throws OrderNotFound;
    List<Order1> getAllOrders();
}