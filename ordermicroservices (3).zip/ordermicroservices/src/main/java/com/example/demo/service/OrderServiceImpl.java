package com.example.demo.service;

	import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dto.BookDTO;
import com.example.demo.dto.CartBookDTO;

//import com.example.demo.dto.BookDTO;

//import com.example.demo.dto.OrderBookDTO;

import com.example.demo.entity.Order1;
import com.example.demo.exception.OrderNotFound;
import com.example.demo.repository.OrderRepository;

	@Service
	public class OrderServiceImpl implements OrderService {

	    @Autowired
	    OrderRepository repository;
		@Autowired
		RestTemplate restTemplate;
//		@Override
//	    public String addOrder(int cartId) {
//	        repository.save(cartId);
//	        return "Order saved successfully!";
//	    }
		Logger logger = LoggerFactory.getLogger(this.getClass());
		
	    @Override
	    public String addOrder1(Order1 order) {
	        repository.save(order);
	        return "Order saved successfully!";
	    }
	    
	    public Order1 placeOrder(int cartId) throws OrderNotFound {
	        logger.info("Placing order for cartId: {}", cartId);
	
	        try {
	            CartBookDTO cartDTO = restTemplate.getForObject("http://CARTMICROSERVICE/carts/getCart/" + cartId, CartBookDTO.class);
	
	            if (cartDTO == null) {
	                logger.error("Cart not found for cartId: {}", cartId);
	                throw new OrderNotFound("Cart not found for cartId: " + cartId);
	            }
	
	            Order1 order = new Order1();
	            order.setCartId(cartDTO.getCartId());
	     
	
	            Order1 savedOrder = repository.save(order);
	            logger.info("Order placed successfully: {}", savedOrder);
	            return savedOrder;
	
	        } catch (Exception e) {
	            logger.error("Error placing order for cartId: {}", cartId, e);
	            throw new OrderNotFound("Error placing order for cartId: " + cartId + ". Reason: " + e.getMessage());
	        }
	    }

	    @Override
	    public Order1 updateOrder(Order1 order) {
	        return repository.save(order);
	    }

	    @Override
	    public String deleteOrder(int orderId) {
	        repository.deleteById(orderId);
	        return "Order deleted successfully!";
	    }
	   
		


	    @Override
	    public Order1 getOrderById(int orderId) throws OrderNotFound {
	        Optional<Order1> optional = repository.findById(orderId);
	        if(optional.isPresent()) 
				return optional.get();
	       
			else
				throw new OrderNotFound("No Orders Found With Given Id!!!");
	  
	    }

	    @Override
	    public List<Order1> getAllOrders() {
	        return repository.findAll();
	    }

//		public Orders1 getOrder(int orderId) {
//			Optional<Orders1> optional = repository.findById(orderId);
//			BookDTO Books = restTemplate.getForObject("http://BOOKSMICROSERVICE/books/getById/" + bookId,
//					BookDTO.class);
//			System.out.println(Books);
//			OrderBookDTO orderBooks = new OrderBookDTO(orderId, Books.getList());
//			return orderBooks;
//		}
	    public BookDTO getBooksByOrderId(int orderId) throws OrderNotFound {
	        Order1 order = getOrderById(orderId);
	        if (order != null) {
	            BookDTO books = restTemplate.getForObject("http://BOOKSMICROSERVICE/books/getAllByCartId/" + order.getCartId(), BookDTO.class);
	            return books;
	        }
	        return null;
	    }

}
