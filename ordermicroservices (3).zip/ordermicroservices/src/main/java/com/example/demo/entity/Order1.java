package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

	@Data
	@Entity
	@NoArgsConstructor
	@AllArgsConstructor
	public class Order1 {
	    @Id
	    @GeneratedValue(strategy= GenerationType.AUTO)
	    private int orderId;
	   // @NotEmpty(message="order status cannot be empty")
	    private String orderStatus="Ordered";
	    @NotNull(message = "cart id cannot be empty")
	    private int cartId;

	    // Add the getter method for cartId
	    public int getCartId() {
	        return cartId;
	    }
		
		
	}


