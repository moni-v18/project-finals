package com.example.demo.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Book {

	@NotEmpty(message="book id cannot be empty")
	private int bookId;
	@NotNull(message="book name cannot be empty")
	private String bookName;
	@NotEmpty(message="book price cannot be empty")
	@Min(500)
	@Max(10000)
	private int bookPrice;
	@NotNull(message="book Author cannot be empty")
	private String bookAuthor;
	@NotNull(message="book genre cannot be empty")
	private String bookGenre;
	@NotEmpty(message="cart Id cannot be empty")
	private int cartId;
}
