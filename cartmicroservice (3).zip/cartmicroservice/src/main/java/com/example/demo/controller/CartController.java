package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CartBookDTO;
import com.example.demo.entity.Cart;
import com.example.demo.exception.CartNotFound;
//import com.example.demo.service.CartService;
import com.example.demo.service.CartServiceImpl;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
//import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/carts")

public class CartController {
	
	@Autowired
	CartServiceImpl service;

	@GetMapping("/test")
	public String test() {
		return "in test";
	}

	@PostMapping("/add") // http://localhost:7771/cart/save
	public String saveCart(@RequestParam int userId,@RequestBody CartBookDTO cartbookDTO) {
		return service.addToCart3(userId,cartbookDTO);
	}
	
	
	
	
	
	
	
	
	
	@PostMapping("/addtoCart")
	public String addToCart(@RequestBody List<Integer> bookList) {
		return service.addToCart1(bookList);
	}

	@GetMapping("/getCart/{cartId}") // http://localhost:7771/cart/getCart/1
	public Cart getCart(@PathVariable("cartId") int cartId) throws CartNotFound {
		System.out.println("in getcart");
		return service.getCartDetails(cartId);
	}
	
	@GetMapping("/getCartId/{cartId}")
	public ResponseEntity<CartBookDTO> getCartById(@PathVariable int cartId) {
	    CartBookDTO cart = service.getCartById(cartId); // Assuming you have a cartService
	    if (cart != null) {
	        return ResponseEntity.ok(cart);
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}
	

}