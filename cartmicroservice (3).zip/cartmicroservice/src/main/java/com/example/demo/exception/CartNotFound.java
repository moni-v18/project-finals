package com.example.demo.exception;

public class CartNotFound extends Exception {
	public CartNotFound(String message) {
		super(message);
	}
}
