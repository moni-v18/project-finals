package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.CartBookDTO;
import com.example.demo.entity.Cart;
import com.example.demo.exception.CartNotFound;

public interface CartService {

	

	//public abstract CartBookDTO getCart(int cartId) throws CartNotFound;
	public  String addToCart(int userId, CartBookDTO cartDTO);

	public abstract Cart getCartDetails(int cartId) throws CartNotFound;
	public String addToCart1(List<Integer> bookList);
}
