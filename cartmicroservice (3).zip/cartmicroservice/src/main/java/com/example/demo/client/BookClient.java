package com.example.demo.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.dto.BookDTO;

@FeignClient("BOOKSMICROSERVICE")
public interface BookClient {
	@GetMapping("/books/getById/{id}") // http://localhost:7772/books/getById/123
	public BookDTO getBook(@PathVariable("id") int bookId);
}
