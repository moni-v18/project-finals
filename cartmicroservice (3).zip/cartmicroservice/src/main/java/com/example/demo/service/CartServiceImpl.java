package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.client.BookClient;
import com.example.demo.client.UserClient;
import com.example.demo.dto.BookDTO;
import com.example.demo.dto.CartBookDTO;
import com.example.demo.dto.UserInfoDTO;
import com.example.demo.entity.Cart;
import com.example.demo.exception.CartNotFound;
import com.example.demo.repository.CartRepository;

@Service
public class CartServiceImpl implements CartService {
	@Autowired
	CartRepository repository;
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	UserClient userClient;
	@Autowired
	BookClient bookClient;

	Logger logger = LoggerFactory.getLogger(this.getClass());



	
	//addtocart with open feign

	public String addToCart(int userId, CartBookDTO cartDTO) {
        try {
            // Check if the user exists
            UserInfoDTO userInfo = userClient.getUserById(userId);
            Cart cart;
 
            if (userInfo == null) {
                // Create a new cart for the user
                cart = new Cart();
                cart.setUserId(userId);
                cart.setBookIdList(cartDTO.getBookIdList());
                repository.save(cart);
                return "User not found. Created a new cart and added books.";
            } else {
                // Check if garments exist
                List<Integer> booksList = cartDTO.getBookIdList();
                if (booksList == null || booksList.isEmpty()) {
                    return "No books to add";
                }
 
                for (Integer bookId : booksList) {
                    if (bookClient.getBook(bookId) == null) {
                        return "Book not found: " + bookId;
                    }
                }
 
                // Add products to existing cart or create a new cart if none exists
                cart = repository.findByUserId(userId);
                if (cart == null) {
                    cart = new Cart();
                    cart.setUserId(userId);
                    cart.setCartId(cartDTO.getCartId());
                    repository.save(cart);
                    return "NEW CART CREATED";
                }
                List<Integer> existingBooks = cart.getBookIdList();
                if (existingBooks == null) {
                    existingBooks = new ArrayList<>();
                }
                existingBooks.addAll(cartDTO.getBookIdList());
                cart.setBookIdList(existingBooks);
                repository.save(cart);
 
                return "Added successfully";
            }
        } catch (Exception e) {
            return "An error occurred: " + e.getMessage();
        }
    }
	public String addToCart3(int userId, CartBookDTO cartDTO) {
	    Cart cart = repository.findByUserId(userId);
        if (cart == null) {
            cart = new Cart();
            cart.setUserId(userId);
            cart.setCartId(cartDTO.getCartId());
            repository.save(cart);
            return "NEW CART CREATED";
        }
        List<Integer> existingBooks = cart.getBookIdList();
        if (existingBooks == null) {
            existingBooks = new ArrayList<>();
        }
        existingBooks.addAll(cartDTO.getBookIdList());
        cart.setBookIdList(existingBooks);
        repository.save(cart);

        return "Added successfully";
	}
	@Override
    public Cart getCartDetails(int cartId) throws CartNotFound {
        Optional<Cart> optional = repository.findById(cartId);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new CartNotFound("Cart details not found");
        }
    }
	
	
	  @Override
		public String addToCart1(List<Integer> medList) {
			logger.info("Adding to cart with medicine list: {}", medList);
			Cart cart = new Cart();
			cart.setBookIdList(medList);
			Cart savedCart = repository.save(cart);
			logger.info("Cart saved successfully: {}", savedCart);
			return "{\"cartId\": " + savedCart.getCartId() + "}";
		}
	
	 public CartBookDTO getCartById(int cartId) {
	        Cart cart = repository.findById(cartId).orElse(null);
	        if (cart == null) {
	            return null;
	        }
   
	        CartBookDTO cartBookDTO = new CartBookDTO();
	        cartBookDTO.setCartId(cart.getCartId());
	        cartBookDTO.setUserId(cart.getUserId());
	        cartBookDTO.setBookIdList(cart.getBookIdList());

	        return cartBookDTO;
	    }


}
