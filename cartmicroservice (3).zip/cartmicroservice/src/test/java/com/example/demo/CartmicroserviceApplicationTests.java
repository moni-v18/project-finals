package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.controller.CartController;
import com.example.demo.dto.Book;
import com.example.demo.dto.CartBookDTO;
import com.example.demo.entity.Cart;
import com.example.demo.service.CartServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(CartController.class)
@SpringBootTest
class CartmicroserviceApplicationTests {

	
    @Autowired
    private MockMvc mockMvc;

    @Mock
    private CartServiceImpl cartService;

    @Test
    public void testGetCart() throws Exception {
        CartBookDTO cartBookDTO = new CartBookDTO(1, Arrays.asList(new Book(1, "Book1", 100, "Author1", "Genre1", 1)));
        when(cartService.getCart(1)).thenReturn(cartBookDTO);

        mockMvc.perform(get("/carts/getCart/1"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.cartId").value(1))
               .andExpect(jsonPath("$.books[0].bookId").value(1));
    }

    @Test
    public void testSaveCart() throws Exception {
        Cart cart = new Cart(1);
        when(cartService.addToCart(cart)).thenReturn(cart);

        mockMvc.perform(post("/carts/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(cart)))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.cartId").value(1));
    }
}

